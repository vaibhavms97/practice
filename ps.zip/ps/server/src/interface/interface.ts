import { Request } from "express";

export interface IUserData {
  name: string,
  id: string,
  email: string
}

export interface IRequest extends Request {
  userData : IUserData
}