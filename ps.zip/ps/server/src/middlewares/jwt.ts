import { NextFunction, Request, Response } from "express";
import * as jwt from "jsonwebtoken"
import { MESSAGES, STATUS } from "../constants/constants";

// Verify JWT token is correct or not
const authenticate = (req: Request,res: Response,next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader ? authHeader.slice(7) : '';
  try {
    jwt.verify(token, process.env.JWT_SECRET as string, (err, decoded) => {
      if(err) {
        res.status(STATUS.AUTHORIZATION_FAILED).json({message: MESSAGES.AUTHORIZATION_FAILED})
      } else if(!decoded) {
        res.status(STATUS.AUTHORIZATION_FAILED).json({message: MESSAGES.AUTHORIZATION_FAILED})
      } else {
        req.body.userData = decoded; //Set user details present in JWT
        next()
      }
    })
  } catch (error) {
    next(error)
  }
}

export default authenticate