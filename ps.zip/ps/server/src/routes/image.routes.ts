import express from "express"
import { addImage, getImage } from "../controllers/image.controller"

const imageRouter = express.Router()

imageRouter.post('/addImage', addImage)
imageRouter.get('/getImage/:id', getImage)

export default imageRouter