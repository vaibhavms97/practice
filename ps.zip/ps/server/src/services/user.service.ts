import { User } from "../models/users.model"

/**
* Function to fetch user
*
* @param {string} email - Email id.
* @returns - User if email id matches.
*/
export const findUser = async (email: string) => {
  return await User.findOne({email})
}

