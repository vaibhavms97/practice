export const USER_CREATED_SUCCESSFUL = "User created SUCCESSFULy"
export const INVALID_PASSWORD = "Invalid username or password"
export const USER_EXISTS = "User already exists"

export const STATUS = {
  OK: 200,
  AUTHORIZATION_FAILED: 403,
  ERROR: 400
}