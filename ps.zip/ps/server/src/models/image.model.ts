import mongoose, * as Mongoose from "mongoose"

const imageSchema = new Mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
}, {timestamps: true})

export const Image = mongoose.model("Image", imageSchema)