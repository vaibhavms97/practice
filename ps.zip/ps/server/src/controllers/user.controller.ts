import { Request, Response } from "express";
import { findUser } from "../services/user.service";
import { User } from "../models/users.model";
import { INVALID_PASSWORD, STATUS, USER_CREATED_SUCCESSFUL, USER_EXISTS } from "../constants/constants";
import jwt from "jsonwebtoken"
import { genSalt, hash, compare } from "bcrypt-ts";

/**
* Controller to signUp user.
*
* @param req - The request object containing user details.
* @param res - The response object used to send back the response.
* @returns - A response with the user details or an error message.
*/
export const signUp = async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;
    const user = await findUser(email)
    const key = process.env.JWT_SECRET as string
    // Check user already exists
    if (user) {
      res.status(STATUS.ERROR).json({
        message: USER_EXISTS
      })
    } else {
      const salt = await genSalt(10);
      const hashedPassword = await hash(password, salt);
      const newUser = {
        name: name.trim(),
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        role: 'USER'
      }
      // Creating new user
      const data = await User.create(newUser)
      const token = jwt.sign({ name: data.name, _id: data._id, email: data.email }, key, { algorithm: "HS256", allowInsecureKeySizes: true, expiresIn: 86400 })
      res.status(STATUS.OK).json({
        success: true,
        message: USER_CREATED_SUCCESSFUL,
        data: {
          userId: data._id,
          token,
          email,
          name: data.name
        }
      })
    }
  } catch (error) {
    res.status(STATUS.ERROR).json({ message: error })
  }
}

/**
* Controller for user sign in.
*
* @param req - The request object containing user details.
* @param res - The response object used to send back the response.
* @returns - A response with the user details or an error message.
*/
export const signIn = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const key = process.env.JWT_SECRET as string
    const user = await findUser(email)
    const passwordMatch = await compare(password, user?.password as string)
    // Check user is present or not
    if (!user) {
      res.status(STATUS.ERROR).json({ message: INVALID_PASSWORD })
    } else if (!passwordMatch) { //Check for password validation
      res.status(STATUS.ERROR).json({ message: INVALID_PASSWORD })
    } else {
      // Generating token when user logged in successfully
      const token = jwt.sign({ name: user.name, _id: user._id, email: user.email }, key, { algorithm: "HS256", allowInsecureKeySizes: true, expiresIn: 86400 })
      res.status(STATUS.OK).json({
        success: true,
        data: {
          userId: user._id,
          token,
          email,
          name: user.name
        }
      })
    }
  } catch (error) {
    res.status(STATUS.ERROR).json({ message: error })
  }
}