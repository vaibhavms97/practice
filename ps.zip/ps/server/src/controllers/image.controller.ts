import { Request, Response } from 'express';
import mongoose from 'mongoose';
import { Image } from '../models/image.model';
import { STATUS } from '../constants/constants';

const connect = mongoose.createConnection(process.env.MONGODB_URI as string)
let gfs: mongoose.mongo.GridFSBucket;

connect.once('open', () => {
  // initialize stream
  gfs = new mongoose.mongo.GridFSBucket(connect.db as mongoose.mongo.Db, {
    bucketName: "prasad-stores-images"
  });
});

export const addImage = async (req: Request, res: Response) => {
  try {
    const { name } = req.body
    const newImage = new Image({
      name
    })
    const createdImage = await newImage.save()
    res.status(STATUS.OK).json({ success: true, data: createdImage })
  } catch (error) {
    res.status(STATUS.ERROR).json({ message: error })
  }
}

export const getImage = async (req: Request, res: Response) => {
  try {
    const imageId = req.params.id;
    let data = await gfs.find({_id: new mongoose.Types.ObjectId(imageId)}).toArray()
    console.log(data.length)
  } catch (error) {
    res.status(STATUS.ERROR).json({ message: error })
  }
}

