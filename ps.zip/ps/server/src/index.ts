import express from 'express';
import mongoose from 'mongoose';
import 'dotenv/config'
import dotenv from "dotenv"
import userRouter from './routes/user.routes';
import cors from 'cors'
import imageRouter from './routes/image.routes';

// Middlewares for security
const app = express();
app.use(cors())
app.use(express.json());

// Env configuration for environments
const envFile = `.env.${process.env.NODE_ENV || 'development'}`
dotenv.config({path: envFile})

// Mongodb connection
mongoose.connect(process.env.MONGODB_URI as string, {dbName: 'prasad-stores'})
.then(() => console.log("Database connected successfully"))

const PORT = 5000;

// Initializing all express routers
app.use('/user', userRouter);
app.use('/image', imageRouter)

app.listen(PORT, () => {
  console.log(
    `Server running on ${PORT}.`
  )
});

export default app;