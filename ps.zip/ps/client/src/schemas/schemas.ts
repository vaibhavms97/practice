import * as yup from "yup"
import { REGEX, SCHEMA_VALIDATION } from "../constants/constants"

export const loginSchema = () => (
  yup.object().shape({
    email: yup.string().email(SCHEMA_VALIDATION.EMAIL).required(SCHEMA_VALIDATION.REQUIRED),
    password: yup.string().min(8).matches(REGEX.PASSWORD, {message: SCHEMA_VALIDATION.INVALID_USERNAME}).required(SCHEMA_VALIDATION.REQUIRED),
  })
)

export const signUpSchema = () => (
  yup.object().shape({
    name: yup.string().min(3, SCHEMA_VALIDATION.USERNAME).required(SCHEMA_VALIDATION.REQUIRED),
    email: yup.string().email(SCHEMA_VALIDATION.EMAIL).required(SCHEMA_VALIDATION.REQUIRED),
    password: yup.string().min(8).matches(REGEX.PASSWORD, {message: SCHEMA_VALIDATION.PASSWORD}).required(SCHEMA_VALIDATION.REQUIRED),
    confirmPassword: yup.string().oneOf([yup.ref("password")], SCHEMA_VALIDATION.CONFIRM_PASSWORD).required(SCHEMA_VALIDATION.REQUIRED)
  })
)

export const productSchema = () => (
  yup.object().shape({
    name: yup.string().required(SCHEMA_VALIDATION.REQUIRED),
    stockAvailable: yup.number().min(0, SCHEMA_VALIDATION.POSITIVE_NUMBER).required(SCHEMA_VALIDATION.REQUIRED),
    qty: yup.string().required(SCHEMA_VALIDATION.REQUIRED),
  })
)

