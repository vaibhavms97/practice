import { useFormik } from "formik"
import { signUpSchema } from "../../schemas/schemas"
import { IUser } from "../../interfaces/interface"
import { postSignUpDetails } from "../../redux/actions/login.action"
import { useDispatch, useSelector } from "react-redux"
import { AppState } from "../../redux/reducers/rootReducer"
import { useEffect } from "react"
import { useNavigate } from "react-router-dom"

const useSignUp = () => {
  const login = useSelector((store: AppState) => store.login)
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
      confirmPassword:'',
      name: '',
    },
    validationSchema: signUpSchema,
    validateOnChange: false,
    onSubmit: (data) => {
      handleSignUp(data)
    }
  })

  useEffect(() => {
    if(login.data.userId) {
      navigate('/')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[login])

  /**
  * Function for handle login and dispatch login action.
  *
  * @param {IUser} data - Gets user details.
  */
  const handleSignUp = async (data: IUser) => {
    dispatch(postSignUpDetails(data))
  }

  return {
    formik,
    login
  }
}

export default useSignUp