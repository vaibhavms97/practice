import Button from "../../core/Button"
import Input from "../../core/Input"
import { IButtonType } from "../../interfaces/customElements"
import Error from "../../core/Error"
import useSignUp from "./useSignUp"
import Loader from "../../sharedComponents/Loader"

const SignUp = () => {
  const {formik, login} = useSignUp()
  const { email, password, name, confirmPassword } = formik.errors

  return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <p className="text-center text-3xl text-primary font-bold">Prasad Stores</p>
      <p className="text-center text-xl mt-3 font-bold">Sign Up</p>
      <form onSubmit={formik.handleSubmit}>
        <Input label="Name" name="name" id="name"  onChange={formik.handleChange} labelClass="mt-3" />
        {name && <Error>{name}</Error>}
        <Input label="Email" name="email" id="email"  onChange={formik.handleChange} labelClass="mt-3" />
        {email && <Error>{email}</Error>}
        <Input label="Password" name="password" id="password" onChange={formik.handleChange} type="password" labelClass="mt-3" />
        {password && <Error>{password}</Error>}
        <Input label="Confirm Password" name="confirmPassword" id="confirmPassword" onChange={formik.handleChange} type="password" labelClass="mt-3" />
        {confirmPassword && <Error>{confirmPassword}</Error>}
        <Button variant={IButtonType.PRIMARY} type="submit" buttonClass="mt-3 w-full" >Sign Up</Button>
      </form>
      {login.isLoading && <Loader />}
    </div>
  )
}

export default SignUp