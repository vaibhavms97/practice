import { useSelector } from "react-redux"
import { AppState } from "../../redux/reducers/rootReducer"
import { productSchema } from "../../schemas/schemas"
import { useFormik } from "formik"
import { IProduct } from "../../interfaces/interface"
import { _post } from "../../util/apiUtil"
import { API_URLS } from "../../constants/constants"

const useAddProduct = () => {
  const login = useSelector((store: AppState) => store.login)
  const formik = useFormik<IProduct>({
    initialValues: {
      name: "",
      qty: "",
      image: null,
      stockAvailable: null,
    },
    validationSchema: productSchema,
    validateOnChange: false,
    onSubmit: (data) => {
      handleSubmit(data)
    }
  })

  async function handleSubmit(data: IProduct) {
    const res = await _post(API_URLS.ADD_IMAGE, data)
    console.log(res)
  }

  return {
    formik
  }

}

export default useAddProduct