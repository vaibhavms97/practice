import Button from "../../core/Button"
import Input from "../../core/Input"
import { IButtonType } from "../../interfaces/customElements"
import Error from "../../core/Error"
import useLogin from "./useLogin"
import { Link } from "react-router-dom"
import Loader from "../../sharedComponents/Loader"

const Login = () => {
  const {formik, login} = useLogin()
  const { email, password } = formik.errors

  return (
    <div className="min-h-screen flex flex-col items-center justify-center">
      <p className="text-center text-3xl text-primary font-bold">Prasad Stores</p>
      <p className="text-center text-xl mt-3 font-bold">Login</p>
      <form onSubmit={formik.handleSubmit}>
        <Input label="Email" name="email" id="email"  onChange={formik.handleChange} labelClass="mt-3" />
        {email && <Error>{email}</Error>}
        <Input label="Password" name="password" id="password" onChange={formik.handleChange} type="password" labelClass="mt-3" />
        {password && <Error>{password}</Error>}
        <Button variant={IButtonType.PRIMARY} type="submit" buttonClass="mt-3 w-full" >Login</Button>
      </form>
      <p className="text-xs text-start mt-2">New User? <Link className="text-primary underline cursor-pointer" to="/sign-up">Register here</Link> </p>
      {login.isLoading && <Loader />}
    </div>
  )
}

export default Login