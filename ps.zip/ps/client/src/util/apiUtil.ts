import axios from 'axios'
import toast from 'react-hot-toast'


// const API_ENDPOINT = import.meta.env.VITE_BACKEND_URL
const API_ENDPOINT = "http://localhost:5000/"

const client = axios.create({
  baseURL: API_ENDPOINT,
  headers: {
    //   Authorization: `Bearer ${localStorage.getItem('token')}`,
    'Content-Type': 'application/json',
  },
  timeout: 20000,
})

client.interceptors.request.use((config) => {
  const requestConfig = config
  const token = sessionStorage.getItem('token')
  requestConfig.headers.Authorization = `Bearer ${token}`
  return requestConfig
})

client.interceptors.response.use(
  (response) => response,
  (error) => {
    const { response } = error
    console.log(error)
    if (response) {
      const errorMessage: string = response.data?.message?._message || response.data?.message
      toast.error(errorMessage)
      if (response.status === 500) {
        // handle server error
      } else if (response.status === 401 || response.status === 403) {
        sessionStorage.clear()
        window.location.reload()
      }
    }
    return Promise.reject(error)
  }
)

// Define common API methods
const _get = (url: string ) => {
  return client.get(url);
};

const _delete = (url: string) => {
  return client.delete(url);
};

const _put = (url: string, data = {}) => {
  return client.put(url, data);
};

const _post = (url: string, data = {}) => {
  return client.post(url, data);
};

const _patch = (url: string, data = {}) => {
  return client.patch(url, data);
};

// Export API methods
export { _get, _delete, _put, _post, _patch };
