import { call, put, takeLatest } from "redux-saga/effects";
import { API_URLS } from "../../constants/constants";
import { FETCH_LOGIN_DETAILS, fetchLoginFailure, fetchLoginSuccess, loginDetailsLoading, POST_SIGN_UP, postSignUpFailure, postSignUpSuccess } from "../actions/login.action";
import { IAction, IUser, IUserDetails } from "../../interfaces/interface";
import { _post } from "../../util/apiUtil";

interface IResponse {
  data: {
    success: boolean,
    data: IUserDetails
  }
}

// Function for fetching login data
const getLoginData = async (loginDetails: IUser) => {
  const res = await _post(API_URLS.LOGIN, loginDetails)
  return res
}

// Login worker for user login
export function* loginWorker(action: IAction) {
  try {
    yield put(loginDetailsLoading())
    const res: IResponse = yield call(getLoginData, action.payload)
    if(res.data.success) {
      sessionStorage.setItem('token', res.data.data.token)
      yield put(fetchLoginSuccess(res.data.data))
    } else {
      yield put(fetchLoginFailure())
    }
  } catch {
    yield put(fetchLoginFailure())
  }
}

// Login watcher for user login
export function* loginWatcher() {
  yield takeLatest(FETCH_LOGIN_DETAILS, loginWorker)
}

// Function for creating new user
const signUp = async (signUpDetails: IUser) => {
  const res = await _post(API_URLS.SIGNUP, signUpDetails)
  return res
}

// SignUp worker for new user sign up
export function* signUpWorker(action: IAction) {
  try {
    yield put(loginDetailsLoading())
    const res: IResponse = yield call(signUp, action.payload)
    if(res.data.success) {
      sessionStorage.setItem('token', res.data.data.token)
      yield put(postSignUpSuccess(res.data.data))
    } else {
      yield put(postSignUpFailure())
    }      
  } catch {
    yield put(postSignUpFailure())
  }
}

// SignUp watcher for new user sign up
export function* signUpWatcher() {
  yield takeLatest(POST_SIGN_UP, signUpWorker)
}

