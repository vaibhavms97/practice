import { all } from "redux-saga/effects";
import { loginWatcher, signUpWatcher } from "./authSaga";

// Function for watching all saga watchers
export function* rootSaga() {
  yield all([
    loginWatcher(),
    signUpWatcher(),
  ])
}