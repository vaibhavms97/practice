import { IUser, IUserDetails } from "../../interfaces/interface"

export const FETCH_LOGIN_DETAILS = "FETCH_LOGIN_DETAILS"
export const FETCH_LOGIN_SUCCESS = "FETCH_LOGIN_SUCCESS"
export const FETCH_LOGIN_FAILURE = "FETCH_LOGIN_FAILURE"
export const POST_SIGN_UP = "POST_SIGN_UP"
export const POST_SIGN_UP_SUCCESS = "POST_SIGN_UP_SUCCESS"
export const POST_SIGN_UP_FAILURE = "POST_SIGN_UP_FAILURE"
export const LOGIN_DETAILS_LOADING = "LOGIN_DETAILS_LOADING"
export const GET_USER_DETAILS = "GET_USER_DETAILS"
export const LOGOUT = "LOGOUT"

// Action for fetching login details
export const fetchLoginDetails = (payload: IUser) => (
  {
    type: FETCH_LOGIN_DETAILS,
    payload
  }
)

// Action when user logged in successfully
export const fetchLoginSuccess = (payload: IUserDetails) => (
  {
    type: FETCH_LOGIN_SUCCESS,
    payload
  }
)

// Action for showing error if login details failed
export const fetchLoginFailure = () => (
  {
    type: FETCH_LOGIN_FAILURE
  }
)

// Action for fetching login details
export const postSignUpDetails = (payload: IUser) => (
  {
    type: POST_SIGN_UP,
    payload
  }
)

// Action when user logged in successfully
export const postSignUpSuccess = (payload: IUserDetails) => (
  {
    type: POST_SIGN_UP_SUCCESS,
    payload
  }
)

// Action for showing error if login details failed
export const postSignUpFailure = () => (
  {
    type: POST_SIGN_UP_FAILURE
  }
)

// Action for logout
export const logout = () => (
  {
    type: LOGOUT
  }
)

// Action for loading user details
export const loginDetailsLoading = () => (
  {
    type: LOGIN_DETAILS_LOADING
  }
)