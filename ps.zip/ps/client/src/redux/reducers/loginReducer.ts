import { VALIDATION_MESSAGES } from "../../constants/constants";
import { IAction, IUserDetails } from "../../interfaces/interface";
import { FETCH_LOGIN_FAILURE, FETCH_LOGIN_SUCCESS, LOGIN_DETAILS_LOADING, LOGOUT, POST_SIGN_UP_FAILURE, POST_SIGN_UP_SUCCESS } from "../actions/login.action";

export const initialLoginState = {
  data: {userId: "", email: "", name:"", token: "", role: ""},
  isLoading: false,
  error: ""
}

interface ILoginState {
  data: IUserDetails,
  isLoading: boolean,
  error: string
}

const loginReducer = (state:ILoginState = initialLoginState, action: IAction) => {
  switch(action.type) {
    case FETCH_LOGIN_SUCCESS: {
      return {
        ...state, data: action.payload, error: "", isLoading: false
      }
    }
    case FETCH_LOGIN_FAILURE: {
      return {
        ...state, error: VALIDATION_MESSAGES.INCORRECT_USERNAME, isLoading: false
      }
    }
    case POST_SIGN_UP_SUCCESS: {
      return {
        ...state, data: action.payload, error: "", isLoading: false
      }
    }
    case POST_SIGN_UP_FAILURE: {
      return {
        ...state, error: VALIDATION_MESSAGES.SOMETHING_WENT_WRONG, isLoading: false
      }
    }
    case LOGIN_DETAILS_LOADING: {
      return {
        ...state, isLoading: true
      }
    }
    case LOGOUT: {
      sessionStorage.clear()
      return {
        ...state, data: initialLoginState.data,
      }
    }
    default:{
      return state
    }
  }
}

export default loginReducer