type BaseInputAttributes = React.ComponentPropsWithoutRef<"input">

export interface IInput extends BaseInputAttributes {
  label: string,
  children?: React.ReactElement | string,
  inputClass?: string
  labelClass?: string
  inputAdornment?: string,
  inputIcon?: any,
  position?: 'start' | 'end'
}

export interface IFileInput extends BaseInputAttributes {
  label: string,
  children?: React.ReactElement | string,
  inputClass?: string
  labelClass?: string
}

type BaseTextAreaAttributes = React.ComponentPropsWithoutRef<"textarea">

export interface ITextArea extends BaseTextAreaAttributes {
  label: string,
  children?: React.ReactElement | string,
  inputClass?: string
  labelClass?: string
}

type BaseButtonAttributes = React.ComponentPropsWithoutRef<"button">;

export enum IButtonType {
  PRIMARY = "PRIMARY",
  ERROR = "ERROR"
}

export interface IButtonProps extends BaseButtonAttributes {
    variant: IButtonType,
    children: React.ReactElement | string,
    buttonClass?: string
}

type BaseSelectAttributes = React.ComponentPropsWithoutRef<"select">

export interface IOption {
  name?: string | number,
  value?: string | number,
  defaultValue?: string
}

export interface ISelect extends BaseSelectAttributes {
  label: string,
  children?: React.ReactElement | string,
  inputClass?: string
  labelClass?: string
  selectFor: string,
}

export interface ICustomError {
  children?: React.ReactElement | string,
}