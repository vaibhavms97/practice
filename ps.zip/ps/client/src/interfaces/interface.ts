export interface IUser {
  name?: string,
  email: string,
  password: string,
  _id?: string
}

export interface IUserDetails {
  name: string,
  userId: string,
  email: string,
  token: string,
  role: string,
  _id?: string,
}

export interface IAction {
  type: string,
  payload?: any
}

export interface IProduct {
  name: string,
  qty: string,
  image: File | null,
  stockAvailable: number | null,
}