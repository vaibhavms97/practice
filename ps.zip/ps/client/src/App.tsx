import { BrowserRouter, Route, Routes } from "react-router-dom"
import Header from "./sharedComponents/Header"
import Login from "./components/Login/Login"
import { Provider } from "react-redux"
import store from "./redux/store/store"
import { Toaster } from "react-hot-toast"
import SignUp from "./components/SignUp/SignUp"

function App() {

  return (
    <>
    <Provider store={store}>
    <Toaster />
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/sign-up" element={<SignUp />} />
        </Routes>
      </BrowserRouter>
    </Provider>
    </>
  )
}

export default App
