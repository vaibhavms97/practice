import { ArrowRightEndOnRectangleIcon, MagnifyingGlassIcon, ShoppingCartIcon, UserCircleIcon } from "@heroicons/react/24/outline"
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { AppState } from "../redux/reducers/rootReducer";
import { useEffect, useState } from "react";
import Input from "../core/Input";

interface IHeaderItems {
  title: string,
  icon: React.ForwardRefExoticComponent<Omit<React.SVGProps<SVGSVGElement>, "ref"> & {
    title?: string;
    titleId?: string;
  } & React.RefAttributes<SVGSVGElement>>,
  badgeValue?: number | string,
  redirect?: string,
  showBeforeLogin: boolean
}

const noHeader = ['/login', '/sign-up']

const Header = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const login = useSelector((store: AppState) => store.login)
  const [loggedIn, setIsLoggedIn] = useState(false)
  const headerItems: IHeaderItems[] = [
    {
      title: "Login",
      icon: ArrowRightEndOnRectangleIcon,
      showBeforeLogin: true,
      redirect: "/login"
    },
    {
      title: "Cart",
      icon: ShoppingCartIcon,
      showBeforeLogin: true,
      redirect: "/cart"
    },
    {
      title: login.data.name,
      icon: UserCircleIcon,
      showBeforeLogin: false
    }
  ]

  useEffect(() => {
    if (login.data.userId) {
      setIsLoggedIn(true)
    }
  }, [login])

  return (
    <>
      {noHeader.includes(location.pathname) ? <></> :
        <div className="bg-blue-600 text-white flex justify-between px-10 py-4 items-center">
          <p className="text-2xl font-bold">Prasad Stores</p>
          <Input name="search" label="" placeholder="Search Rice, dal" inputClass="pl-2! dark:focus:border-transparent! dark:focus:ring-transparent! focus:ring-transparent! border-white!" position="start" inputIcon={<MagnifyingGlassIcon className="w-5 h-5 text-black" />}></Input>
          <div className="flex gap-5">
            {headerItems.map((item) => {
              if (!loggedIn && item.showBeforeLogin) {
                return <button key={item.title} type="button" className="flex gap-1 cursor-pointer" onClick={() => navigate(item.redirect as string)}>
                  <item.icon className="w-5" />
                  {item.title}
                </button>
              } else if (loggedIn && !item.showBeforeLogin) {
                return <button key={item.title} type="button" className="flex gap-1 cursor-pointer" onClick={() => navigate(item.redirect as string)}>
                  <item.icon className="w-5" />
                  {item.title}
                </button>
              }
            })}
          </div>
        </div>
      }
    </>
  )
}

export default Header