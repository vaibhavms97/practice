import clsx from "clsx"
import { IInput } from "../interfaces/customElements"

const Input: React.FC<IInput> = ({ label, inputClass, placeholder, children, labelClass, name, inputAdornment,inputIcon, position="start", ...rest }: IInput) => {
  return (
    <div>
      <label htmlFor={name} className={clsx("block text-sm text-gray-500 dark:text-gray-300", labelClass)}>{label}</label>
      <div className="flex items-center">
        {inputAdornment &&
          <p
            className={
              clsx(
                "mt-2 py-2.5 h-full px-3 text-gray-500 bg-gray-100 dark:bg-gray-800 dark:border-gray-700 border border-r-0",
                position === "start" && "rounded-l-lg",
                position === "end" && "hidden"
              )
            }
          >
            {inputAdornment}
          </p>
        }
        {inputIcon &&
          <p
            className={
              clsx(
                "mt-2 placeholder-gray-400/70 dark:placeholder-gray-500 border border-gray-200 bg-white px-2.5 py-3 text-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:focus:border-blue-300 border border-r-0",
                position === "start" && "rounded-l-lg",
                position === "end" && "hidden"
              )
            }
          >
            {inputIcon}
          </p>
        }
        <input
          name={name}
          {...rest}
          placeholder={placeholder}
          className={
            clsx(
              "block mt-2 w-full placeholder-gray-400/70 dark:placeholder-gray-500 rounded-lg border border-gray-200 bg-white px-5 py-2.5 text-gray-700 focus:border-blue-400 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-40 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:focus:border-blue-300",
              inputClass,
              inputAdornment || inputIcon && position === "start" && "rounded-l-none",
              inputAdornment || inputIcon && position === "end" && "rounded-r-none"
            )
          }
        >
          {children}
        </input>
        {inputAdornment &&
          <p
            className={
              clsx(
                "mt-2 py-2.5 px-3 text-gray-500 bg-gray-100 dark:bg-gray-800 dark:border-gray-700 border border-r-0",
                position === "start" && "hidden",
                position === "end" && "rounded-r-lg rounded-l-none border-l-0 border-r"
              )
            }
          >
            {inputAdornment}
          </p>
        }
      </div>  
    </div>
  )
}

export default Input