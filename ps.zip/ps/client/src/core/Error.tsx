import { ICustomError } from "../interfaces/customElements.ts"

const Error = ({children}: ICustomError) => {
  return (
    <p className="text-red-500 text-xs mt-1">{children}</p>
  )
}

export default Error