import { IOption } from "../interfaces/customElements.ts"

const Option = ({value, name, ...rest}: IOption) => <option value={value} {...rest}>{name}</option>

export default Option