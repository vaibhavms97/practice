import clsx from "clsx"
import { IButtonProps, IButtonType } from "../interfaces/customElements.ts"

const Button: React.FC<IButtonProps> = (props:IButtonProps) => {
  const {variant,children,buttonClass, ...rest} = props
  return (
      <button className={clsx("px-4 py-2 font-small text-white capitalize transition-colors duration-300 transform rounded-lg focus:outline-none focus:ring", variant === IButtonType.PRIMARY ? "bg-blue-600 hover:bg-blue-500 focus:ring-blue-200" : "bg-red-600 hover:bg-red-500 focus:ring-red-200", buttonClass)} {...rest}>
          {children}
      </button>
  )
}

export default Button