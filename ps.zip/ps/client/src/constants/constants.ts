export const REGEX = {
  PASSWORD: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
}

export const SCHEMA_VALIDATION = {
  EMAIL: "Please enter a valid email",
  REQUIRED: "Required",
  INVALID_USERNAME: "Invalid username or password",
  USERNAME: "Username must be at least 3 characters long",
  PASSWORD: "Please create a strong password",
  CONFIRM_PASSWORD: "Passwords must match",
  POSITIVE_NUMBER: "Should be positive"
}

export const  API_URLS = {
  LOGIN: "/user/signIn",
  SIGNUP: "/user/signUp",
  ADD_IMAGE: "/image/addImage"
}

export const VALIDATION_MESSAGES = {
  INCORRECT_USERNAME: "Incorrect username or password",
  SOMETHING_WENT_WRONG: "Something went wrong!, please try again later",
  SIGNED_UP_SUCCESS: "Signed up successfully",
}